package com.example.u34a1q3;

import static org.junit.Assert.*;

public class Main2ActivityTest {

}