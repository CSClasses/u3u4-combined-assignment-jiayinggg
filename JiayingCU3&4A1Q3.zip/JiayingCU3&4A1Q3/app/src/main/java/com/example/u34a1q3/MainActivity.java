package com.example.u34a1q3;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import static android.widget.Toast.*;

public class MainActivity extends AppCompatActivity {
    // set the price as a public variable so that every function can access it
    public static double price;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // load the layout and everything to the screen
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    // write a function for the final calculation
    public void setfinal(int percent){
        // use getresult to find the amount of tip
        double tip = getresult(percent);
        // find the textview
        TextView finalamount = (TextView) findViewById(R.id.finalamount);
        double finalprice = tip + price;
        // load the final amount up
        finalamount.setText(String.valueOf(finalprice));

    }
    public void getText(View view){
        //  the code for the next button
        TextInputEditText edit = (TextInputEditText)findViewById(R.id.price);
        // get the price that user typed in
        String result = "";
        // to handle the case that user doesnt put an input
        try{
            result = edit.getText().toString();
            price = Double.valueOf(result);
            TextView tenprice = (TextView) findViewById(R.id.ten);



            // calculate the 10% tip and update it to the page
            double tentip = getresult(10);
            tenprice.setText(String.valueOf(tentip));

            // calculate the 20% tip and update it to the page
            TextView twoprice = (TextView) findViewById(R.id.two);
            double twotip = getresult(20);
            twoprice.setText(String.valueOf(twotip));

            // calculate the 25% tip and update it to the page
            TextView twofiveprice = (TextView) findViewById(R.id.twofive);
            double twofivetip = getresult(25);
            twofiveprice.setText(String.valueOf(twofivetip));


        }catch(Exception e){


            // to send notification
            Toast toast= makeText(getApplicationContext(),"Please type in a number", LENGTH_SHORT);
            toast.setMargin(50,50);
            toast.show();




        }



    }

    // calculate the tip
    private double getresult(int percent){
        int toint = (int) (MainActivity.price * percent);
        double out = toint/100.0;
        return out;

    }

    // update final for 10%
    public void setTen(View view){
        setfinal(10);

    }
    // update final for 20%
    public void settwen(View view){
        setfinal(20);

    }
    // update final for 25%
    public void settwofive(View view){
        setfinal(25);

    }
    // update final for self-type in
    public void selfsetting(View view){
        // get user input
        TextInputEditText type = (TextInputEditText)findViewById(R.id.typein);

        String in = type.getText().toString();
        Double inside = Double.valueOf(in);
        // set the final price
        TextView finalamount = (TextView) findViewById(R.id.finalamount);
        double finalprice = inside + price;
        finalamount.setText(String.valueOf(finalprice));
    }


}
