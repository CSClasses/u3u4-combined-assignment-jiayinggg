/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jiayingcu3.pkg4a1q1;


import java.io.File;
import java.io.IOException;
import java.util.*;



import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author jiayingcui
 */
public class JiayingCU34A1Q1 extends JFrame 
    implements ActionListener {
    // create textfield button and other globle varible so that all the method can have access to them
    private JTextField text;
    private static JiayingCU34A1Q1 frame;
    private JButton back;
    public static Document doc;
    public static Map<String, ArrayList> place2weather = new HashMap<>();
    private JPanel window;
    private String place;
    
    private ArrayList<String> resultlist;
   
    // write a function to get an attribute of a node giving attribute name and node
    public static String getValue(Node node, String attri){
        Element element = (Element) node;
        return element.getAttribute(attri);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent event) {
        // change the input to uppercase as all the station in the doc is capitalized
        place = text.getText().toUpperCase();
        // if the button "next" is clicked
        if(event.getActionCommand().equals("Next") && place2weather.keySet().contains(place)){
            // remove everything from that window so that leave space for showing searching result
            window.removeAll();
            // initial the back button
            back = new JButton("Back");
            // start the new panel for the backbutton so that it wont interference with the searching result
            JPanel backpanel = new JPanel();
            backpanel.add(back);
            back.addActionListener(this);
            
            
            
            resultGUI();
            // add the backpanel to the center of the panel 
            frame.add(backpanel,BorderLayout.CENTER);
            frame.setVisible(true);
            
            
            // paint the panel
            window.revalidate();
            window.repaint(); 
        
         // handle the case if the user click the back button   
        }else if(event.getActionCommand().equals("Back")){
            window.removeAll();
            
            frame.createGUI();
            window.revalidate();
            window.repaint(); 
            
            
        }else{
            //creating a dialog for input error
            JFrame warning = new JFrame();
            
            JOptionPane.showMessageDialog(warning,
            "I am sorry but the information of this station is not included",
            "Not including",
            JOptionPane.INFORMATION_MESSAGE);
            warning.setVisible(true);
           
            
        }
        
        
        
        
    
        
        
    }
    // user a method to get All the node with the same tag
    public static ArrayList<String> getTagList(String tag,Element element){
        
        ArrayList<String> returnone = new ArrayList<>();
        // get the nodelist by the element name 
        NodeList nodeList = element.getElementsByTagName(tag);
        for(int i = 0; i < nodeList.getLength();i++){
            // get the first thing in the nodelist
            if(nodeList.item(i).getNodeType() == Node.ELEMENT_NODE){
                returnone.add(nodeList.item(i).getNodeValue());
            }
        }
        
        return returnone; 
        
    }
    // write a function to handling the way to set result
    private void oneResult(String item,int num){
        
        JLabel relabel= new JLabel(item);
        JTextField refield = new JTextField(resultlist.get(num),10);
        window.add(relabel);
        window.add(refield);
    }
    
    private void resultGUI(){
        //setting the result page one by one
        //get the list from the dictionary
        resultlist = place2weather.get(place);
        window.setLayout(new GridLayout(3, 4));
        
        oneResult("Max Temperature", 0);
        oneResult("Mean Temperature",1);
        oneResult("Min Temperature",2);
        oneResult("         Snow",3);
        oneResult("Precipitate",4);
        
        
        
    }
    private void createGUI() {
        
        

        // create the basic gui
        window = new JPanel();
        window.setBorder(BorderFactory.createTitledBorder("Caring about Weather"));
        window.setPreferredSize(new java.awt.Dimension(500, 100));
        
        window.setLayout(new FlowLayout());
        // ask for the station name
        JLabel askforname = new JLabel("Please Enter the Station Name: ");
        text = new JTextField(35);
        text.addActionListener(this);
        // add the button
        JButton next = new JButton("Next");
        next.addActionListener(this);
        window.add(askforname);
        window.add(text);
        window.add(next);
        
        
        add(window,BorderLayout.NORTH);
        
    }
    
    
    public static ArrayList<String> getweather(Node node){
        
        // get all the number needed from the nodelist
        Node maxtemp = doc.getElementsByTagName("max_temperature").item(0);
        Node meantemp  = doc.getElementsByTagName("mean_temperature").item(0);
        Node mintemp  = doc.getElementsByTagName("min_temperature").item(0);
        Node snow  = doc.getElementsByTagName("snow").item(0);
        Node precipitate  = doc.getElementsByTagName("precipitation").item(0);
        // create a list in order to add to the dictionary latter
        ArrayList<String> addon = new ArrayList<>();
        // add all the value
        addon.add(getValue(maxtemp,"value"));
        addon.add(getValue(meantemp,"value"));
        addon.add(getValue(mintemp,"value"));
        addon.add(getValue(snow,"total"));
        addon.add(getValue(precipitate,"total"));
        
        
        return addon;
        
        
        
    }
    
    
    public static void main(String[] args) {
        //load the xml file
        String filePath = "eng-climate-summaries-All-4,2018.xml";
        File xmlFile = new File(filePath);
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        try {
            // turn the xml to the nodelist
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            NodeList nodeList = doc.getElementsByTagName("station");
            
            
            
            
            
                
            // go through everything in the xml file and add them to the dictionary
            for (int i = 0; i < nodeList.getLength(); i++) {
                String name;
                
                if(nodeList.item(i).getNodeType() == Element.ELEMENT_NODE){
                    // get all the name node
                    Element element = (Element)nodeList.item(i);
                    NodeList nameList = element.getElementsByTagName("name").item(0).getChildNodes();
                    
                    Node node = nameList.item(0);
                    name = node.getNodeValue();
                    // use funtion to get everything needed and add it to the dictionary
                    ArrayList<String> theList = getweather(nodeList.item(i));
                
                    place2weather.put(name,theList);
                    
                    
                    
                    
                }
         
                
                
            }
            
            
            
         
        } catch (SAXException | ParserConfigurationException | IOException e1) {
            e1.printStackTrace();
        }
        
        
        // basic GUI setting(frame)
        frame = new JiayingCU34A1Q1();
        frame.setSize(550,500);
        frame.setTitle("Weather");
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null); 
        frame.createGUI();
        
        frame.setVisible(true);
    }
     
       
            
        


    
}
