//
//  ViewController.swift
//  JiayingCU3&4A1Q4
//
//  Created by Jiaying Cui on 2019-05-20.
//  Copyright © 2019 Jiaying Cui. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    

    
    @IBOutlet weak var show: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // use the textfield to display the value of the slide
    @IBAction func theSlide(_ sender: UISlider) {
        show.text = String(Int(sender.value))
    }
    
    
    @IBOutlet weak var showresult: UITextField!
    
    @IBAction func next(_ sender: UIButton) {
        let num = Int(show.text!)!
        // check the result and printout the right result
        if(num>28 && num < 33){
            
            showresult.text = "Congratulation! You are right. "
            
        }else {
             showresult.text = "The answer is suppose to be around 31%. "
            
        }
        
        
        
        
    }
    
    // take the user input
    @IBOutlet weak var theanswer: UITextField!
    
    @IBOutlet weak var outcome: UIImageView!
    @IBAction func checkanswer(_ sender: Any) {
        let answer = theanswer.text!
        if answer.isEqual("Eukaryote") {
            outcome.image = UIImage(named: "right.jpg")
        }else {
            outcome.image = UIImage(named: "wrong.jpg")
            
        }
    }
}

